import{a as t}from"../chunks/entry.ad7f1u77.js";export{t as start};
